#<?php die('Direct Access To Log Files Not Permitted'); ?>
#Version: 1.0
#Date: 2010-11-19 07:39:02
#Fields: date	time	level	c-ip	status	comment
#Software: Joomla! 1.6.0 Beta14 [ Onward ] 15-Nov-2010 23:00 GMT
2010-11-19	07:39:02	-	::1	Joomla FAILURE: 	User does not exist
2010-11-27	23:45:28	-	127.0.0.1	Joomla FAILURE: 	Invalid password