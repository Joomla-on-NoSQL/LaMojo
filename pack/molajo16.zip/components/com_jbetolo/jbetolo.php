<?php
/**
 * @version		2.0-beta-140 - 2010 November 23 01:07:23 +0100
 * @package		jbetolo
 * @copyright		Copyright © 2010 - All rights reserved.
 * @license		GNU/GPL
 * @author		Gobezu Sewu
 * @author mail		info@jproven.com
 * @website		http://jproven.com
 */
 
defined('_JEXEC') or die('Restricted access');

require_once JPATH_ADMINISTRATOR.'/components/com_jbetolo/jbetolo.php';

?>