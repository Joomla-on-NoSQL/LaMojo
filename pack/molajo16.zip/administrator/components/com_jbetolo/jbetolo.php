<?php
/**
 * @version		2.0-beta-140 - 2010 November 23 01:07:23 +0100
 * @package		jbetolo
 * @copyright		Copyright © 2010 - All rights reserved.
 * @license		GNU/GPL
 * @author		Gobezu Sewu
 * @author mail		info@jproven.com
 * @website		http://jproven.com
 *
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

$task = JRequest::getCmd('task');

require_once dirname(__FILE__).'/helper.php';

$lang = JFactory::getLanguage();
$lang->load('plg_system_jbetolo');

switch ($task) {
        case 'serve':
                $file = JRequest::getString('file', false);
                $type = JRequest::getString('type', false);

                if ($file && $type) {
                        jbetoloComponentHelper::sendFile($type, $file);
                } else {
                        $file = JRequest::getString('cfile', false);
                        
                        if (!$file) die('Restricted access');

                        jbetoloComponentHelper::sendFile('htaccess', $file);
                }

                break;
        case 'clearcache':
                die(jbetoloComponentHelper::resetCache());
                break;
        case 'resetsetting':
                die(jbetoloComponentHelper::resetSetting());
                break;
        case 'savesetting':
                die(jbetoloComponentHelper::saveSetting());
                break;
        case 'smushit':
                die(jbetoloComponentHelper::smushIt());
                break;
        default:
                break;
}

?>