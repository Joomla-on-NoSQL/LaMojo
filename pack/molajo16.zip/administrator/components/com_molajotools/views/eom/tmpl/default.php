<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: default.php 517 2010-12-10 22:37:03Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

?>
<div class="width-100">
	<fieldset class="adminform">
		<p>
			<form action="index.php">
				<input type="hidden" name="option" value="com_molajotools" />
				<input type="hidden" name="view" value="eom" />
				<input type="hidden" name="task" value="offline" />
				<input type="submit" value="<?php echo JText::_('MTOOLS_LBL_APPLY') ?>" /><hr />
			</form>
		</p>

<?php if(!$this->offline): ?>
	<p><?php echo JText::_('MTOOLS_LBL_EOM_PREAPPLY') ?></p>
	<p><?php echo JText::_('MTOOLS_LBL_EOM_PREAPPLYMANUAL') ?></p>
	<pre><?php echo $this->htaccess ?></pre>
<?php else: ?>
	<p>
		<form action="index.php">
			<input type="hidden" name="option" value="com_molajotools" />
			<input type="hidden" name="view" value="eom" />
			<input type="hidden" name="task" value="online" />
			<input type="submit" value="<?php echo JText::_('MTOOLS_LBL_UNAPPLY') ?>" /><hr />
		</form>
	</p>
	<p><?php echo JText::_('MTOOLS_LBL_EOM_PREUNAPPLY') ?></p>
	<p><?php echo JText::_('MTOOLS_LBL_EOM_PREUNAPPLYMANUAL') ?></p>
<?php endif; ?>
	</fieldset>
</div>