<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: default.php 517 2010-12-10 22:37:03Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

$lang = JFactory::getLanguage();
$option = JRequest::getCmd('option','com_molajotools');
?>
<div class="width-50 fltlft">
<form name="adminForm" id="adminForm" action="index.php" method="post">
	<input type="hidden" name="option" value="com_molajotools" />
	<input type="hidden" name="view" value="wafconfig" />
	<input type="hidden" name="task" value="save" />

	<fieldset class="adminform">
		<legend><?php echo JText::_('MTOOLS_LBL_WAF_OPTGROUP_BASIC') ?></legend>
		
		<div class="editform-row">
			<label for="adminpw" title="<?php echo JText::_('MTOOLS_LBL_WAF_OPT_ADMINPW_TIP'); ?>"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_ADMINPW'); ?></label>
			<input type="text" size="20" name="adminpw" value="<?php echo $this->config['adminpw'] ?>" title="<?php echo JText::_('MTOOLS_LBL_WAF_OPT_ADMINPW_TIP') ?>" />
		</div>
		<div class="editform-row">
			<label for="sqlishield"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_SQLISHIELD'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('sqlishield', array(), $this->config['sqlishield']) ?>
		</div>
		<div class="editform-row">
			<label for="custgenerator"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_CUSTGENERATOR'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('custgenerator', array(), $this->config['custgenerator']) ?>
		</div>
		<div class="editform-row">
			<label for="generator"><?php echo JText::_('MTOOLS_LBL_WAF_GENERATOR'); ?></label>
			<input type="text" size="45" name="generator" value="<?php echo $this->config['generator'] ?>" title="<?php echo JText::_('MTOOLS_LBL_WAF_GENERATOR_TIP') ?>" />
		</div>
		<div class="editform-row">
			<label for="nonewadmins"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_NONEWADMINS'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('nonewadmins', array(), $this->config['nonewadmins']) ?>
		</div>
		<div class="editform-row">
			<label for="encodedby"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_ENCODEDBY'); ?></label>
			<input type="text" size="45" name="encodedby" value="<?php echo $this->config['encodedby'] ?>" />
		</div>
		<div class="editform-row">
			<label for="poweredby"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_POWEREDBY'); ?></label>
			<input type="text" size="45" name="poweredby" value="<?php echo $this->config['poweredby'] ?>" />
		</div>
		<div class="editform-row">
			<label for="nojoomla"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_NOJOOMLA'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('nojoomla', array(), $this->config['nojoomla']) ?>
		</div>

	</fieldset>
</div>
<div class="width-50 fltrt">
	<fieldset class="adminform">
		<legend><?php echo JText::_('MTOOLS_LBL_WAF_OPTGROUP_FINGERPRINTING') ?></legend>

		<div class="editform-row">
			<label for="tmpl"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_TMPL'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('tmpl', array(), $this->config['tmpl']) ?>
		</div>
		<div class="editform-row">
			<label for="template"><?php echo JText::_('MTOOLS_LBL_WAF_OPT_TEMPLATE'); ?></label>
			<?php echo MolajotoolsHelperSelect::booleanlist('template', array(), $this->config['template']) ?>
		</div>
	</fieldset>
</div>
</form>