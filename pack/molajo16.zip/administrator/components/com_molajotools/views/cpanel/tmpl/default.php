<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: default.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

$lang = JFactory::getLanguage();
$option = JRequest::getCmd('option','com_molajotools');

$root = @realpath(JPATH_ROOT);
$root = trim($root);
$emptyRoot = empty($root);

$confirm = JText::_('MTOOLS_LBL_PURGESESSIONS_WARN', true);
$script = <<<ENDSCRIPT
window.addEvent( 'domready' ,  function() {
	$('optimize').addEvent('click', warnBeforeOptimize)
});


function warnBeforeOptimize(e)
{
	if(!confirm('$confirm'))
	{
		e.preventDefault();
	}
}
ENDSCRIPT;
$document = JFactory::getDocument();
$document->addScriptDeclaration($script,'text/javascript');

JHTML::_('behavior.modal');
?>
<?php if($emptyRoot): ?>
<div class="disclaimer molajotools-warning">
	<?php echo JText::_('MTOOLS_LBL_CP_EMPTYROOT'); ?>
</div>
<?php endif; ?>

<div>
	<div id="mtcpanel">

		<h2><?php echo JText::_('MTOOLS_LBL_CP_SECURITY') ?></h2>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=eom">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/eom-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_EOM') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_EOM') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<?php $icon = $this->adminLocked ? 'locked' : 'unlocked'; ?>
		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=adminpw">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/adminpw-<?php echo $icon ?>-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_ADMINPW') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_ADMINPW') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=wafconfig">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/waf-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_WAFCONFIG') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_WAFCONFIG') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="clear: both;"></div>

		<h2><?php echo JText::_('MTOOLS_LBL_CP_TOOLS') ?></h2>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=fixpermsconfig">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/fixpermsconfig-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_FIXPERMSCONFIG') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_FIXPERMSCONFIG') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=fixperms&tmpl=component" class="modal" rel="{handler: 'iframe', size: {x: 600, y: 250}, onClose: function() {}}">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/fixperms-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_FIXPERMS') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_FIXPERMS') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=cleantmp&tmpl=component" class="modal" rel="{handler: 'iframe', size: {x: 600, y: 250}, onClose: function() {}}">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/cleantmp-32.png"
					border="0" alt="<?php echo JText::_('MOLAJOTOOLS_TITLE_CLEANTMP') ?>" />
					<span>
						<?php echo JText::_('MOLAJOTOOLS_TITLE_CLEANTMP') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=dbchcol">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/dbchcol-32.png"
					border="0" alt="<?php echo JText::_('MTOOLS_LBL_DBCHCOL') ?>" />
					<span>
						<?php echo JText::_('MTOOLS_LBL_DBCHCOL') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=dbtools&task=optimize&tmpl=component" class="modal" rel="{handler: 'iframe', size: {x: 600, y: 250}, onClose: function() {}}">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/dbtools-optimize-32.png"
					border="0" alt="<?php echo JText::_('MTOOLS_LBL_OPTIMIZEDB') ?>" />
					<span>
						<?php echo JText::_('MTOOLS_LBL_OPTIMIZEDB') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="float:<?php echo ($lang->isRTL()) ? 'right' : 'left'; ?>;">
			<div class="icon">
				<a href="index.php?option=<?php echo $option ?>&view=dbtools&task=purgesessions" id="optimize">
					<img
					src="<?php echo JURI::base(); ?>../media/com_molajotools/images/dbtools-32.png"
					border="0" alt="<?php echo JText::_('MTOOLS_LBL_PURGESESSIONS') ?>" />
					<span>
						<?php echo JText::_('MTOOLS_LBL_PURGESESSIONS') ?><br/>
					</span>
				</a>
			</div>
		</div>

		<div style="clear: both;"></div>
		<div id="disclaimer" class="atoolsblock" style="margin-top: 2em;">
			<h3><?php echo JText::_('MTOOLS_LBL_CP_DISCLAIMER') ?></h3>
			<p><?php echo JText::_('MTOOLS_LBL_CP_DISTEXT'); ?></p>
			<hr/>
			<h3>Credits</h3>
			<p>
				Molajo Tools is a special version of Admin Tools, written and maintained by
				<a href="http://www.akeebabackup.com">AkeebaBackup.com</a>. Molajo Tools is
				Free Software, distributed under the terms of the
				<a href="http://www.gnu.org/licenses/gpl.html">GNU
				General Public Licence (GPL), version 3 of the license</a> or, at your
				option, any later version published by the Free Software Foundation.
			</p>
		</div>

	</div>
	
</div>

<div style="clear: both;"></div>