<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: view.html.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

// Load framework base classes
jimport('joomla.application.component.view');

class MolajotoolsViewCpanel extends JView
{
	function display()
	{
		// Is this the Professional release?
		jimport('joomla.filesystem.file');

		// Set the toolbar title
		JToolBarHelper::title(JText::_('MOLAJOTOOLS_TITLE_DASHBOARD_CORE'),'molajotools');

		// Load the models
		$model =& $this->getModel();
		$adminpwmodel = $this->getModel('adminpw');

		// Decide on the administrator password padlock icon
		$adminlocked = $adminpwmodel->isLocked();
		$this->assign('adminLocked',			$adminlocked);

		// Load CSS
		$document = JFactory::getDocument();
		$document->addStyleSheet('../media/com_molajotools/css/backend.css');

		parent::display();
	}
}