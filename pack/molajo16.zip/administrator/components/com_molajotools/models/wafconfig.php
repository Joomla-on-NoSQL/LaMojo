<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: wafconfig.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

jimport('joomla.application.component.model');

class MolajotoolsModelWafconfig extends JModel
{
	var $defaultConfig = array(
		'ipwl'			=> 0,
		'ipbl'			=> 0,
		'adminpw'		=> '',
		'blockinstall'	=> 0,
		'nonewadmins'	=> 0,
		'encodedby'		=> '',
		'poweredby'		=> '',
		'nojoomla'		=> 0,
		'sqlishield'	=> 0,
		'antispam'		=> 0,
		'custgenerator'	=> 0,
		'generator'		=> '',
		'tpone'			=> 0,
		'tmpl'			=> 0,
		'template'		=> 0,
		'logbreaches'	=> 0
	);

	function getConfig()
	{
		$component =& JComponentHelper::getComponent( 'com_molajotools' );
		$params = new JParameter($component->params);
		$config = $params->toArray();
		$config = array_merge($this->defaultConfig, $config);
		return $config;
	}

	function saveConfig($newParams)
	{
		$component =& JComponentHelper::getComponent( 'com_molajotools' );
		$params = new JParameter($component->params);

		foreach($newParams as $key => $value)
		{
			$params->set($key,$value);
		}

		$db =& JFactory::getDBO();
		$data = $params->toString();

		// Joomla! 1.6
		$sql = 'UPDATE `#__extensions` SET `params` = '.$db->Quote($data).' WHERE '.
			"`element` = 'com_molajotools' AND `type` = 'component'";

		$db->setQuery($sql);
		$db->query();
	}
}