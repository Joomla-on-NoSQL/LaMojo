<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: customperms.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

if(!class_exists('MolajotoolsTable'))
{
	require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'tables'.DS.'base.php';
}

class TableCustomperms extends MolajotoolsTable
{
	var $id = 0;
	var $path = '';
	var $perms = '0644';

	function __construct( &$db )
	{
		parent::__construct( '#__molajotools_customperms', 'id', $db );
	}
}
