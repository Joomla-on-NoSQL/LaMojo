<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: molajotools.php 485 2010-12-03 12:08:17Z AmyStephen $
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

defined('_JEXEC') or die();

jimport('joomla.filesystem.file');

// Access check, Joomla! 1.6 style.
if (!JFactory::getUser()->authorise('core.manage', 'com_molajotools')) {
	return JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));
}

// Get the view and controller from the request, or set to default if they weren't set
JRequest::setVar('view', JRequest::getCmd('view','cpanel'));
JRequest::setVar('c', JRequest::getCmd('view','cpanel')); // Get controller based on the selected view

// Merge the default translation with the current translation
$jlang =& JFactory::getLanguage();
// Back-end translation
$jlang->load('com_molajotools', JPATH_ADMINISTRATOR, 'en-GB', true);
$jlang->load('com_molajotools', JPATH_ADMINISTRATOR, $jlang->getDefault(), true);
$jlang->load('com_molajotools', JPATH_ADMINISTRATOR, null, true);

// If JSON functions don't exist, load our compatibility layer
if( (!function_exists('json_encode')) || (!function_exists('json_decode')) )
{
	require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'helpers'.DS.'jsonlib.php';
}

// Load the appropriate controller
$c = JRequest::getCmd('c','cpanel');
$path = JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.$c.'.php';
$alt_path = JPATH_COMPONENT_ADMINISTRATOR.DS.'plugins'.DS.'controllers'.DS.$c.'.php';
if(JFile::exists($path))
{
	// The requested controller exists and there you load it...
	require_once($path);
}
elseif(JFile::exists($alt_path))
{
	require_once($alt_path);
}
else
{
	$view = JRequest::getCmd('view','');
	$viewFolder = JPATH_COMPONENT_ADMINISTRATOR.DS.'views'.DS.$view;
	if(!JFolder::exists($viewFolder))
	{
		// Hmm... an invalid controller was passed
		JError::raiseError('500',JText::_('Unknown controller').' '.$c);
	}
	require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';
	$c = 'default';
}

// Instanciate and execute the controller
jimport('joomla.utilities.string');
$c = 'MolajotoolsController'.ucfirst($c);
$controller = new $c();
$controller->execute(JRequest::getCmd('task','display'));

// Redirect
$controller->redirect();