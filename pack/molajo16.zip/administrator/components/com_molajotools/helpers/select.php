<?php
/**
 * @package AkeebaReleaseSystem
 * @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 * @license GNU General Public License version 3, or later
 * @version $Id: select.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

defined('_JEXEC') or die('Restricted access');

class MolajotoolsHelperSelect
{
	protected static function genericlist($list, $name, $attribs, $selected, $idTag)
	{
		if(empty($attribs))
		{
			$attribs = null;
		}
		else
		{
			$temp = '';
			foreach($attribs as $key=>$value)
			{
				$temp .= $key.' = "'.$value.'"';
			}
			$attribs = $temp;
		}

		return JHTML::_('select.genericlist', $list, $name, $attribs, 'value', 'text', $selected, $idTag);
	}

	public static function booleanlist( $name, $attribs = null, $selected = null )
	{
		$options = array(
			JHTML::_('select.option','-1','---'),
			JHTML::_('select.option',  '0', JText::_( 'No' ) ),
			JHTML::_('select.option',  '1', JText::_( 'Yes' ) )
		);
		return self::genericlist($options, $name, $attribs, $selected, $name);
	}

	public static function perms( $name, $attribs = null, $selected = null )
	{
		$rawperms = array(0400,0444,0600,0644,0664,0700,0740,0744,0750,0754,0755,0775,0777);

		$options = array();
		$options[] = JHTML::_('select.option','','---');

		foreach($rawperms as $perm)
		{
			$text = decoct($perm);
			$options[] = JHTML::_('select.option','0'.$text,$text);
		}
		return self::genericlist($options, $name, $attribs, $selected, $name);
	}

}