<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: adminpw.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

class MolajotoolsControllerAdminpw extends MolajotoolsControllerDefault
{
	public function protect()
	{
		$username = JRequest::getVar('username','');
		$password = JRequest::getVar('password','');
		$password2 = JRequest::getVar('password2','');

		if(empty($username)) {
			$this->setRedirect('index.php?option=com_molajotools&view=adminpw',JText::_('MTOOLS_ERR_ADMINPW_NOUSERNAME'),'error');
			return;
		}

		if(empty($password)) {
			$this->setRedirect('index.php?option=com_molajotools&view=adminpw',JText::_('MTOOLS_ERR_ADMINPW_NOPASSWORD'),'error');
			return;
		}

		if($password != $password2) {
			$this->setRedirect('index.php?option=com_molajotools&view=adminpw',JText::_('MTOOLS_ERR_ADMINPW_PASSWORDNOMATCH'),'error');
			return;
		}

		$model = $this->getThisModel();

		$model->username = $username;
		$model->password = $password;

		$status = $model->protect();
		$url = 'index.php?option=com_molajotools';
		if($status)
		{
			$this->setRedirect($url,JText::_('MTOOLS_LBL_ADMINPW_APPLIED'));
		}
		else
		{
			$this->setRedirect($url,JText::_('MTOOLS_ERR_ADMINPW_NOTAPPLIED'),'error');
		}
	}

	public function unprotect()
	{
		$model = $this->getThisModel();
		$status = $model->unprotect();
		$url = 'index.php?option=com_molajotools';
		if($status)
		{
			$this->setRedirect($url,JText::_('MTOOLS_LBL_ADMINPW_UNAPPLIED'));
		}
		else
		{
			$this->setRedirect($url,JText::_('MTOOLS_ERR_ADMINPW_NOTUNAPPLIED'),'error');
		}
	}
}
