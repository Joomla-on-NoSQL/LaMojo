<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: cpanel.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

class MolajotoolsControllerCpanel extends MolajotoolsControllerDefault
{
	public function display()
	{
		$model = $this->getModel('Adminpw',	'MolajotoolsModel');

		$view = $this->getThisView();
		$view->setModel($model,	false);
		
		parent::display();
	}
}
