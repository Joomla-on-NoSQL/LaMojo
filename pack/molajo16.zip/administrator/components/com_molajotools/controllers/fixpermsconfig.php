<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: fixpermsconfig.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

class MolajotoolsControllerFixpermsconfig extends MolajotoolsControllerDefault
{
	public function savedefaults()
	{
		$model = $this->getThisModel();
		$model->setState('dirperms', JRequest::getCmd('dirperms','0755'));
		$model->setState('fileperms', JRequest::getCmd('fileperms','0644'));
		$model->saveDefaults();

		$message = JText::_('MTOOLS_LBL_FIXPERMSCONFIG_DEFAULTSSAVED');
		$this->setRedirect('index.php?option=com_molajotools&view=fixpermsconfig', $message);
	}

	public function  display($cachable = false) {
		$path = JRequest::getVar('path','');

		$model = $this->getThisModel();
		$model->setState('path',$path);
		$model->applyPath();

		parent::display($cachable);
	}

	/**
	 * Saves the custom permissions and reloads the current view
	 */
	public function saveperms()
	{
		$this->save_custom_permissions();
		
		$message = JText::_('MTOOLS_LBL_FIXPERMSCONFIG_CUSTOMSAVED');
		$this->setRedirect('index.php?option=com_molajotools&view=fixpermsconfig&path='.urlencode($path), $message);
	}
	
	/**
	 * Saves the custom permissions, applies them and reloads the current view
	 */
	public function saveapplyperms()
	{
		$this->save_custom_permissions(true);
		
		$message = JText::_('MTOOLS_LBL_FIXPERMSCONFIG_CUSTOMSAVEDAPPLIED');
		$this->setRedirect('index.php?option=com_molajotools&view=fixpermsconfig&path='.urlencode($path), $message);
	}
	
	private function save_custom_permissions($apply = false)
	{
		$path = JRequest::getVar('path','');

		$model = $this->getThisModel();
		$model->setState('path',$path);
		$model->applyPath();

		$folders = JRequest::getVar('folders', array(), 'default', 'array', $mask = 2);
		$model->setState('folders', $folders);
		$files = JRequest::getVar('files', array(), 'default', 'array', $mask = 2);
		$model->setState('files', $files);

		$model->savePermissions($apply);
	}
}
