<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: eom.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

/**
 * Emergency Off-Line Mode
 */
class MolajotoolsControllerEom extends MolajotoolsControllerDefault
{
	public function offline()
	{
		$model = $this->getThisModel();

		$status = $model->putOffline();
		$url = 'index.php?option=com_molajotools';
		if($status)
		{
			$this->setRedirect($url,JText::_('MTOOLS_LBL_EOM_APPLIED'));
		}
		else
		{
			$this->setRedirect($url,JText::_('MTOOLS_ERR_EOM_NOTAPPLIED'),'error');
		}
	}

	public function online()
	{
		$model = $this->getThisModel();
		$status = $model->putOnline();
		$url = 'index.php?option=com_molajotools';
		if($status)
		{
			$this->setRedirect($url,JText::_('MTOOLS_LBL_EOM_UNAPPLIED'));
		}
		else
		{
			$this->setRedirect($url,JText::_('MTOOLS_ERR_EOM_NOTUNAPPLIED'),'error');
		}
	}
}
