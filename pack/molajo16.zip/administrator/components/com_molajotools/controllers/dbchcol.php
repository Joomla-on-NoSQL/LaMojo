<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: dbchcol.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die();

jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

class MolajotoolsControllerDbchcol extends MolajotoolsControllerDefault
{
	public function apply()
	{
		error_reporting(E_ALL);
		$model = $this->getThisModel();
		$collation = JRequest::getString('collation','utf8_general_ci');
		$model->changeCollation($collation);
		
		$msg = JText::_('MTOOLS_LBL_DBCHCOLDONE');
		$this->setRedirect('index.php?option=com_molajotools&view=dbchcol', $msg);
	}	
}