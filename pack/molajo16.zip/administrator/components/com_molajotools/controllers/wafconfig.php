<?php
/**
 *  @package AdminTools
 *  @copyright Copyright (c)2010 Nicholas K. Dionysopoulos
 *  @license GNU General Public License version 3, or later
 *  @version $Id: wafconfig.php 485 2010-12-03 12:08:17Z AmyStephen $
 */

// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

jimport('joomla.application.component.controller');

require_once JPATH_COMPONENT_ADMINISTRATOR.DS.'controllers'.DS.'default.php';

class MolajotoolsControllerWafconfig extends MolajotoolsControllerDefault
{
	public function apply()
	{
		$model = $this->getThisModel();
		$data = JRequest::get('post');
		$model->saveConfig($data);

		$this->setRedirect('index.php?option=com_molajotools&view=wafconfig',JText::_('MTOOLS_LBL_WAF_CONFIGSAVED'));
	}
}
